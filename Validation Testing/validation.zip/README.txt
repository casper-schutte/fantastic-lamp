Unzip all of the files

Install the fantastic-lamp conda environment

With all of the files in the same folder (and the env active), run:

bash validation_test.sh

OR 

conda run -n fantastic-lamp bash validation_test.sh

